<div class="w3-sidebar w3-bar-block w3-white w3-animate-left " style="display: none;z-index: 9999;" id="mySidebar">
		<div class="row w3-white py-3">
			@foreach($titles as $title)
			<div class="col-12 ml-2">
				<img src="{{ $title->img }}" alt="" class="w-50">
			</div>
			@endforeach
		</div>
		<a href="{{ route('home.index') }}" class="w3-bar-item w3-button">Home</a>

		@foreach($menus as $menu)
	  	<a href="{{route('home.menu',$menu->id)}}" class="w3-bar-item w3-button">{{ $menu->name }}</a>
	  	@endforeach
	  	
	  	<a href="{{ route('contact.index') }}" class="w3-bar-item w3-button">Contact Us</a>
</div>

<div id="myOverlay" class="w3-overlay" onclick="w3_close()" style="cursor:pointer">
</div>

<!--nav bar start  -->
<nav class="navbar navbar-expand-lg  navbar-light py-2 shadow sticky-top bg-light">	
	
@foreach($titles as $title)	
	  	<a class="navbar-brand" href="{{ route('home.index') }}"><img src="{{ $title->img }}" style="height: 40px "></a>
@endforeach	  	

	  	<button class="navbar-toggler" type="button"  onclick="w3_open()">
	    	<span class="navbar-toggler-icon"></span>
	  	</button>

	  	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav ml-auto">
		    	<li class="nav-item mx-2 px-2 "><a class="nav-link @if(Request::segment(1) == '') active @endif" href="{{ route('home.index') }}">Home</a></li>
		    	

		    	@foreach($menus as $menu)
		      	<li class="nav-item mx-2 px-2 "><a class="nav-link @if(Request::segment(2) == $menu->id) active @endif" href="{{route('home.menu',$menu->id)}}">{{ $menu->name }}</a></li>
		      	@endforeach
		      	     
		      	<li class="nav-item mx-2 px-2 "><a class="nav-link @if(Request::segment(1) == 'contact') active @endif" href="{{ route('contact.index') }}">Contact Us</a></li>

               
		      	<form method="GET" action="{{ route('search') }}" class="form-inline my-2  my-lg-0 ml-auto">
    				<input class="form-control" name="query" type="search" placeholder="Search" aria-label="Search">
    				
                    <a href=""><i class="fas fa-search fa-2x ml-2"></i></a>



  				</form>
		      
		    </ul>
	  	</div>
</nav>
<!-- nav bar end -->

<!-- banner slide -->
{{-- <div class="container">
		<div class="bd-example">
		  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
		    <ol class="carousel-indicators">
		      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
		      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
		    </ol>
		    <div class="carousel-inner" role="listbox">
		      <div class="carousel-item active">
		        <img class="d-block w-100" src="{{asset('user/image/news/q.jpg')}}" alt="First slide">
		        <div class="carousel-caption d-none d-md-block">
		          <h3>First slide label</h3>
		          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
		        </div>
		      </div>
		      <div class="carousel-item">
		        <img class="d-block w-100" src="{{asset('user/image/news/s.jpg')}}" alt="Second slide">
		        <div class="carousel-caption d-none d-md-block">
		          <h3>Second slide label</h3>
		          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
		        </div>
		      </div>
		       <div class="carousel-item">
		        <img class="d-block w-100" src="{{asset('user/image/news/t.jpg')}}" alt="Second slide">
		        <div class="carousel-caption d-none d-md-block">
		          <h3>Second slide label</h3>
		          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
		        </div>
		      </div>
		       <div class="carousel-item">
		        <img class="d-block w-100" src="{{asset('user/image/news/p.jpg')}}" alt="Second slide">
		        <div class="carousel-caption d-none d-md-block">
		          <h3>Second slide label</h3>
		          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
		        </div>
		      </div>
		    </div>
		    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
		      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		      <span class="sr-only">Previous</span>
		    </a>
		    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
		      <span class="carousel-control-next-icon" aria-hidden="true"></span>
		      <span class="sr-only">Next</span>
		    </a>
		  </div>
		</div>
</div> --}}

<!-- first container -->
<div class="container">
	<div class="row">
		<div class="col-12 col-sm-12 col-md-6 col-lg-8">
			  <h2 class="font-weight-bold">BBC News</h2>
		      @foreach($titles as $title)	
			  <iframe width="700" height="450" src="https://www.youtube.com/embed/{{ $title->youtube_link }}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			  @endforeach
		</div>
		<div class="col-12 col-sm-12 col-md-12 col-lg-4">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<h3 class="font-weight-bold">Up To Date News</h3>
					</div>
					<div class="list-group ">
						@foreach($recents as $recent)
						<div class="card">
									<div class="card-body">
									    <h4 class="card-title font-weight-bold">
									    	{{ $recent->title }}
									     </h4>
									    <h6 class="card-subtitle mb-2 text-muted">
									    	{{ $recent->created_at->diffForHumans() }}
									    </h6>
									    <p class="card-text">
									      {!!htmlspecialchars_decode(str_limit($recent->content, 100)) !!}
									    </p>
									    <a href="{{route('home.post', $recent->id)}}" class="text-primary stretched-link">Read More</a>
									   
									</div>
						</div>
						@endforeach
						
					</div>

					</div>
				</div>
					
				</div>
			</div>
		</div>
				
		</div>

    </div>
</div>