<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Menu;
use App\Http\Resources\Menus;

class ApiController extends Controller
{
    public function getAllmenus()
    {
    	return new Menus(Menu::orderBy('id', 'desc')->get(['id','name']));
    }
}
