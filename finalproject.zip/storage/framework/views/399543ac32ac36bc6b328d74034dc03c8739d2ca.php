  
<?php $__env->startSection('head-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                           
                        <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('post.index')); ?>">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>

                            Edit Post <font size="5px"><b> => <?php echo e($post->title); ?></b></font>

                    </h1>
                </div>
                <div class = "row">
                   <div class="col-12 col-sm-12 col-md-6">
                        <form role="form" action="<?php echo e(route('post.update', $post->id)); ?>" method="post">
                            
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-group">

                                <label>Title</label><br>
                                <span style="color:red;">
                                  *<?php echo e($errors->first('title')); ?>

                                </span>
                                <input class="form-control" name="title" value="<?php echo e(old('title', $post->title)); ?>" >     
                                
                            </div>
                            <div class="form-group">

                                <label>Menu Name</label><br>
                                <span style="color:red;">
                                  *<?php echo e($errors->first('name')); ?>

                                </span>
                                <select name="menu_id" class="form-control">
                                	
							                  <option value="">---select---</option>

                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($menu->id); ?>" <?php echo e($menu->id == $post->menu_id? 'selected': ''); ?>>
                                        <?php echo e($menu->name); ?>

                                      </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>     
                                
                            </div><br>
                            <div class="form-group">
                              <div class="input-group">

          												   <span class="input-group-btn">
          												     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
          												       <i class="fa fa-picture-o"></i> Choose
          												     </a>
          												   </span>
          												   <input id="thumbnail" class="form-control" type="text" name="img" value="<?php echo e(old('img', $post->img)); ?>">
					                    </div>

				                    	<img id="holder" style="margin-top:15px;max-height:100px;">

					                    </div> 

         										<div class="form-group">

         											<textarea id="my-editor" name="content" class="form-control">
                                      <?php echo e($post->content); ?>

                              </textarea>

         										</div> 

                            <div class="form-group">

                                <label>Edit By</label><br>
                                <span style="color:red;">
                                  *<?php echo e($errors->first('name')); ?>

                                </span>
                                <input class="form-control" name="user" value="<?php echo e(Auth::user()->name); ?>" >     
                                
                            </div>  

                            <input type="submit" value="Save Change" class="btn btn-primary">


                        </form>
                                
                   </div>
                            


                </div>
                        
            </div>
        </div>
    </div>  


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>
 <script src="/vendor/laravel-filemanager/js/lfm.js"></script>
 <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
 <script>

   var options = {
        filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
        filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
        filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
        filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
   };

  CKEDITOR.replace('my-editor', options);

 $('#lfm').filemanager('file');

 </script>


  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/post/edit.blade.php ENDPATH**/ ?>