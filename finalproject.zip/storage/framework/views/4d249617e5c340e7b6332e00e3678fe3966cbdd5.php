<?php $__env->startSection('head-section'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

     <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                           
                                <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('menu.index')); ?>">
                                        <i class="fa fa-arrow-left"></i> Back
                                    </a>
                                    Edit Menu

                            </h1>
                        </div>
                        <div class = "row">
                             <div class="col-12 col-sm-12 col-md-6">
                                   <form role="form" action="<?php echo e(route('menu.update', $menu->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                        <div class="form-group">

                                            <label>Menu Name</label><br>
                                            <span style="color:red;">
                                              *<?php echo e($errors->first('name')); ?>

                                            </span>
                                            <input class="form-control" name="name" value="<?php echo e(old('name', $menu->name)); ?>" >     
                                            
                                        </div>
                                        
                                        
                                       
                                          <input type="submit" value="Save Change" class="btn btn-primary">


                                   </form>
                                
                             </div>
                            


                        </div>
                        
                    </div>
                  </div>
                </div>  


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-section'); ?>


  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/menu/edit.blade.php ENDPATH**/ ?>