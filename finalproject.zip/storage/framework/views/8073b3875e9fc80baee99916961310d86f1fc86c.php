<?php $__env->startSection('head-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                           
                                    Dashboard
                                   
                            </h1>
                        </div>
                        <div class = "row">
                        	<div class="col-12" >
		                        <div class="col-lg-3 col-md-6">
		                            <div class="panel panel-primary">
		                                <div class="panel-heading">
		                                    <div class="row">
		                                        <div class="col-xs-3">
		                                            <i class="fa fa-navicon fa-5x"></i>
		                                        </div>
		                                        <div class="col-xs-9 text-right">
		                                            <div class="huge"><?php echo e($menus->count()); ?></div>
		                                            <div>Menus</div>
		                                        </div>
		                                    </div>
		                                </div>
		                                <a href="<?php echo e(route('menu.index')); ?>">
		                                    <div class="panel-footer">
		                                        <span class="pull-left">View Details</span>
		                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

		                                        <div class="clearfix"></div>
		                                    </div>
		                                </a>
		                            </div>
		                        </div>
		                        <div class="col-lg-3 col-md-6">
			                            <div class="panel panel-green">
			                                <div class="panel-heading">
			                                    <div class="row">
			                                        <div class="col-xs-3">
			                                            <i class="fa fa-pencil-square-o fa-5x"></i>
			                                        </div>
			                                        <div class="col-xs-9 text-right">
			                                        	
			                                            <div class="huge"><?php echo e($posts->count()); ?></div>
			                                            <div>Posts</div>
			                                            
			                                        </div>
			                                    </div>
			                                </div>
			                                <a href="<?php echo e(route('post.index')); ?>">
			                                    <div class="panel-footer">
			                                        <span class="pull-left">View Details</span>
			                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

			                                        <div class="clearfix"></div>
			                                    </div>
			                                </a>
			                            </div>
                                </div>
                                <div class="col-lg-3 col-md-6">
			                            <div class="panel panel-yellow">
			                                <div class="panel-heading">
			                                    <div class="row">
			                                        <div class="col-xs-3">
			                                            <i class="fa fa-user fa-5x"></i>
			                                        </div>
			                                        <div class="col-xs-9 text-right">
			                                            <div class="huge"><?php echo e($users->count()); ?></div>
			                                            <div>Users!</div>
			                                        </div>
			                                    </div>
			                                </div>
			                                <a href="<?php echo e(route('user.index')); ?>">
			                                    <div class="panel-footer">
			                                        <span class="pull-left">View Details</span>
			                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

			                                        <div class="clearfix"></div>
			                                    </div>
			                                </a>
			                            </div>
                                 </div>
                                 <div class="col-lg-3 col-md-6">
                            <div class="panel panel-red">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-eye fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?php echo e($all_views); ?></div>
                                            <div>All View</div>
                                        </div>
                                    </div>
                                </div>
                                <a href="<?php echo e(route('post.index')); ?>">
                                    <div class="panel-footer">
                                        <span class="pull-left">View Details</span>
                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                        <div class="clearfix"></div>
                                    </div>
                                </a>
                            </div>
                        </div>

                                 

                                 
                     </div>
                     
                </div>
                <div class = "row">
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Viewer Chart for Week
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div id="morris-bar-chart">
                                    <?php echo $chart->container(); ?>

                                </div>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>

                    

                	<div class="col-lg-6">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                   Most Popular
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Title</th>
                                                    <th>Upload By</th>
                                                    <th>viewer</th>
                                                    <th>See Post</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            	<?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="success">
                                                	
                                                    <td><?php echo e($key + 1); ?></td>
                                                    <td><?php echo e(str_limit($post->title,'20')); ?></td>
                                                    <td><?php echo e($post->created_by); ?></td>
                                                    <td><?php echo e($post->view_count); ?></td>
                                                    <td class="center"><a href="<?php echo e(route('home.post',$post->id)); ?>"class="btn btn-outline btn-success"><i class="fa fa-arrow-right"></i></a></td>
                                                    
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                    </div>

                        
                    
                        
                </div>	
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
<?php echo $chart->script(); ?>


<?php $__env->stopSection(); ?>                

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/dashboard/show.blade.php ENDPATH**/ ?>