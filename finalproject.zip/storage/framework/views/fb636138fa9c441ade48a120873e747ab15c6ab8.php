<?php $__env->startSection('head-section'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                User-Admin 
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create', Auth::user())): ?>
                                    <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('user.create')); ?>">
                                            <i class="fa fa-plus"></i> Add User
                                    </a>
                                <?php endif; ?>

                            </h1>
                        </div>
                        
                    </div>
                    <div class="col-12">
                        <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Admin Role</th>
                                                    <th>Status</th>
                                                    <th>Date</th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update', Auth::user())): ?>
                                                    <th>Edit</th>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete', Auth::user())): ?>
                                                    <th>Deleted</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    
                                                     <td><?php echo e($loop->index +1); ?></td>
                                                     <td><?php echo e($user->name); ?></td>
                                                     <td><?php echo e($user->email); ?></td>
                                                     <td>
                                                         
                                                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                            <?php echo e($role->name); ?>,
                                                            
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     </td>
                                                     <td><?php echo e($user->status? 'Active' : 'Not Active'); ?></td>
                                                     <td><?php echo e($user->created_at->diffForHumans()); ?></td>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update', Auth::user())): ?>
                                                     <td class="center"><a href="<?php echo e(route('user.edit',$user->id)); ?>"class="btn btn-social-icon btn-bitbucket"><i class="fa fa-pencil"></i></a></td>
                                                 <?php endif; ?> 
                                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete', Auth::user())): ?>   

                                                    <td class="center">
             <form id="delete-form-user-<?php echo e($user->id); ?>" action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

             </form>
                                                        <a onclick="deleteConfirm(<?php echo e($user->id); ?>)" class="btn btn-social-icon btn-google-plus">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </td>
                                                  <?php endif; ?>  
 


                                                </tr>

                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                               
                                               
                                                
                                            </tbody>
                                        </table>
                                    </div>
                        
                    </div>
                    
                </div>
                
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>

<script>

            function getConfirm()
            {
                alert('ok');
            }
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });



            function deleteConfirm(id)
            {
                var config = confirm('Are Your Sure');
                if(config)
                {
                  $('#delete-form-user-'+id).submit();
                }
            }
 </script>
  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/user/show.blade.php ENDPATH**/ ?>