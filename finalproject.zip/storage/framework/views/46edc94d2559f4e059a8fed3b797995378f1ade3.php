<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	
	<div class="row">
            <div class="col-md-6"> 
              
              <div style="width: 50%;">
              	
              	<?php echo $chart->container(); ?>

              </div>
              
            </div>
    </div> 

</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
<?php echo $chart->script(); ?>

</html><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/chart.blade.php ENDPATH**/ ?>