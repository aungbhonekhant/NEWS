<?php $__env->startSection('head-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                
                                
                                 <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('menu.create')); ?>">
                                        <i class="fa fa-plus"></i> Add Menu
                                    </a>
                               

                            </h1>
                        </div>

                        
                        
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Date</th>
                                                        <th>Edit</th>
                                                        <th>Deleted</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <tr>
                                                            

                                                            
                                                            <td><?php echo e($loop->index +1); ?></td>
                                                            <td><?php echo e($menu->name); ?></td>
                                                            <td><?php echo e($menu->created_at->diffForHumans()); ?></td>
                                                            <td class="center"><a href="<?php echo e(route('menu.edit',$menu->id)); ?>"class="btn btn-social-icon btn-bitbucket"><i class="fa fa-pencil"></i></a></td>
                                                            <td class="center">
                             <form id="delete-form-menu-<?php echo e($menu->id); ?>" action="<?php echo e(route('menu.destroy',$menu->id)); ?>" method="post" style="display: none;">

                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                             </form>
                                                            <a onclick="ConfirmDelete(<?php echo e($menu->id); ?>)" class="btn btn-social-icon btn-google-plus">
                                                                <i class="fa fa-trash"></i>
                                                            </a>
                                                        </td>
                                                        </tr>

                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                            
                        </div>
                    </div>
                    
                </div>
                
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>

<script>

            function getConfirm()
            {
                alert('ok');
            }
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });



            function ConfirmDelete(id)
            {
                var config = confirm('Are Your Sure');
                if(config)
                {
                  $('#delete-form-menu-'+id).submit();
                }
            }
 </script>
  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/menu/show.blade.php ENDPATH**/ ?>