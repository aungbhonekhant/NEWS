<?php $__env->startSection('head-section'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                Admin Roles
                                <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('permission.create')); ?>" >
                                        <i class="fa fa-plus" ></i> Add Permission
                                    </a>

                            </h1>
                        </div>
                        
                    </div>
                    <div class="col-12">
                        <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Permmissions</th>
                                                    <th>Permission for</th>
                                                    <th>Date</th>
                                                    <th>Edit</th>
                                                    <th>Deleted</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                             <tr>
                                                 <td><?php echo e($loop->index +1); ?></td>
                                                 <td><?php echo e($permission->name); ?></td>
                                                 <td><?php echo e($permission->for); ?></td>
                                                 <td><?php echo e($permission->created_at->diffForHumans()); ?></td>

                                                 <td class="center"><a href="<?php echo e(route('permission.edit',$permission->id)); ?>"class="btn btn-social-icon btn-bitbucket"><i class="fa fa-pencil"></i></a></td>

                                                    <td class="center">
             <form id="delete-form-permission-<?php echo e($permission->id); ?>" action="<?php echo e(route('permission.destroy',$permission->id)); ?>" method="post" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

             </form>
                                                        <a onclick="deleteConfirm(<?php echo e($permission->id); ?>)" class="btn btn-social-icon btn-google-plus">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </td>

                                             </tr>




                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                               
                                                
                                            </tbody>
                                        </table>
                                    </div>
                        
                    </div>
                    
                </div>
                
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-content'); ?>

<script>

            function getConfirm()
            {
                alert('ok');
            }
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });



            function deleteConfirm(id)
            {
                var config = confirm('Are Your Sure');
                if(config)
                {
                  $('#delete-form-permission-'+id).submit();
                }
            }
 </script>
  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/permission/show.blade.php ENDPATH**/ ?>