 <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Admin Pannel</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="<?php echo e(asset('admin/css/metisMenu.min.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('admin/css/startmin.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="<?php echo e(asset('admin/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- Social Buttons CSS -->
        <link href="<?php echo e(asset('admin/css/bootstrap-social.css')); ?>" rel="stylesheet">

        <!-- DataTables CSS -->
        <link href="<?php echo e(asset('admin/css/dataTables/dataTables.bootstrap.css')); ?>" rel="stylesheet">

        <!-- DataTables Responsive CSS -->
        <link href="<?php echo e(asset('admin/css/dataTables/dataTables.responsive.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin/css/morris.css')); ?>" rel="stylesheet">

         
<?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/layout/head.blade.php ENDPATH**/ ?>