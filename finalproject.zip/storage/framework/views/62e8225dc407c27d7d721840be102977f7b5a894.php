<?php $__env->startSection('head-section'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

     <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                           
                                <a class="btn btn-social btn-bitbucket" href="<?php echo e(route('user.index')); ?>">
                                    <i class="fa fa-arrow-left"></i> Back
                                </a>
                                Edit User
                            </h1>
                        </div>
                        <div class = "row">
                             <div class="col-12 col-sm-12 col-md-6">
                                  <form method="POST" action="<?php echo e(route('user.update',  $user->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>


                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right">
                                                <?php echo e(__('Name')); ?>

                                        </label>

                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name', $user->name)); ?>"  autocomplete="name" autofocus>

                                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>

                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email', $user->email)); ?>" autocomplete="email">

                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                    

                                   

                                   
                                    
                                    <div class="form-group row">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>

                                        <div class="col-md-6">
                                            <div class="checkbox">
                                                 <label>
                                                    
                                                     <input type="hidden" name="status" value="0">
                                                     <input type="checkbox" name="status" <?php if(old('status') == 1 || $user->status == 1 ): ?>

                                                        checked
                                                          
                                                     <?php endif; ?>  value="1">
                                                     
                                                     Status
                                                     
                                                 </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>
                                         <div class="col-md-8">
                                            <div class="row">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  
                                                 <div class="col-md-6">
                                                    <div class="checkbox">
                                                         <label>
                                                             <input type="checkbox" name="role[]" value="<?php echo e($role->id); ?>" <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($role->id ==$userrole->pivot->role_id ? 'checked':''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                                             <?php echo e($role->name); ?>

                                                             
                                                         </label>
                                                    </div>
                                                 </div> 
                                                  
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                             </div>           
                                             
                                         </div>
                                        

                                    </div>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                Save Change
                                            </button>
                                        </div>
                                    </div>
                    </form>
                                
                             </div>
                            


                        </div>
                        
                    </div>
                  </div>
                </div>  


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-section'); ?>


  <?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>