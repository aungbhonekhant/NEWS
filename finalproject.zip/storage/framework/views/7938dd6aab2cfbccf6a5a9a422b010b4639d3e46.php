<div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="">Admin Pannel</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="<?php echo e(route('home.index')); ?>"><i class="fa fa-home fa-fw"></i> <?php echo e('Finel Project'); ?></a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> <?php echo e(Auth::user()->name); ?> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                           
                            <li class="divider"></li>
                            <li><a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?></a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            
                            <li>
                                <a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.title', Auth::user())): ?>
                             <li>
                                <a href="<?php echo e(route('title.index')); ?>"><i class="fa fa-gear fa-fw"></i> Site Setting</a>
                            </li>
                            <?php endif; ?>
                             
                             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.menu', Auth::user())): ?>
                             <li>
                                <a href="<?php echo e(route('menu.index')); ?>"><i class="fa fa-navicon fa-fw"></i>Menu</a>
                            </li>
                            <?php endif; ?>
                            
                            <li>
                                <a href="<?php echo e(route('post.index')); ?>"><i class="fa fa-pencil-square-o fa-fw"></i>Post</a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.role', Auth::user())): ?>
                            <li>
                                <a href="<?php echo e(route('role.index')); ?>"><i class="fa fa-shield fa-fw"></i>Role</a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.permission', Auth::user())): ?>
                            <li>
                                <a href="<?php echo e(route('permission.index')); ?>"><i class="fa fa-shield fa-fw"></i>Permissions</a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('user.index')); ?>"><i class="fa fa-user fa-fw"></i>User</a>
                            </li>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.filemanager', Auth::user())): ?>
                            <li>
                                <a href="<?php echo e(route('filemanager.index')); ?>"><i class="fa fa-file fa-fw"></i>File Manager</a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('message.index')); ?>"><i class="fa fa-envelope fa-fw"></i>User Message</a>
                            </li>
                            
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>