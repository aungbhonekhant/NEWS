<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('user.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('head.content'); ?>
</head>
<body>
	
	<?php echo $__env->make('user.layout.postheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('post-content'); ?>


	<?php echo $__env->make('user.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('footer-content'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/user/layout/postapp.blade.php ENDPATH**/ ?>