  </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo e(asset('admin/js/metisMenu.min.js')); ?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo e(asset('admin/js/startmin.js')); ?>"></script>
        <!-- DataTables JavaScript -->
        <script src="<?php echo e(asset('admin/js/dataTables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/dataTables/dataTables.bootstrap.min.js')); ?>"></script>  
        <script src="<?php echo e(asset('admin/js/morris.data.js')); ?>"></script>  
        <script src="<?php echo e(asset('admin/js/morris.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/raphael.min.js')); ?>"></script>
        
         
        


    <?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>