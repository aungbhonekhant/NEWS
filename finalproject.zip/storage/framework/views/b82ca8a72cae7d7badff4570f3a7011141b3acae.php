<?php $__env->startSection('content'); ?>

<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v4.0"></script>

<div class="container-fluid py-4">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h1 class="font-weight-bold">Popular Posts</h1>
			</div>
		</div>

		
		<div class="row">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="col-12 col-sm-12 col-md-6 col-lg-6 mt-3">
				<div class="shadow">
					<img src="<?php echo e($post->img); ?>" alt="" class="w-100">
					<div class="px-4 pb-4">
						<h3><?php echo e(str_limit($post->title, 50)); ?></h3>
						<p>
							<i class="fas fa-user w3-text-green"></i>
							<span class="w3-text-green ml-2"><?php echo e($post->created_by); ?></span>
							<i class="fas fa-calendar"></i>
							<span><?php echo e($post->created_at->diffForHumans()); ?></span> 
						</p>
						<p>
							<?php echo htmlspecialchars_decode(str_limit($post->content, 130)); ?>

						</p>
						<a href="<?php echo e(route('home.post', $post->id)); ?>" class="btn px-4 w3-round-xxlarge shadow">Read more</a><br><br><br>
						
						<a href="<?php echo e(route('home.post', $post->id)); ?>">
					    	
					    	Comment <i class="fa fa-comment"></i>
					    	<span class="fb-comments-count" data-href="http://finalproject.com/post/<?php echo e($post->id); ?>"></span>
					    </a>
					    |
					    <a href="#">
					    	
					    	View <i class="fa fa-eye"></i>
					    	<small><?php echo e(views($post)->count()); ?></small>
					    </a>

					</div>

				</div>
			</div><br><br>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div><br><br>
	<?php echo e($posts->links()); ?>

		

	</div>
</div>		

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-content'); ?>
<script>
		function w3_open() {
		  document.getElementById("mySidebar").style.display = "block";
		  document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
		  document.getElementById("mySidebar").style.display = "none";
		  document.getElementById("myOverlay").style.display = "none";
		}
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/user/home.blade.php ENDPATH**/ ?>