<?php $__env->startSection('head-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                File Manager
                                

                            </h1>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <iframe src="/laravel-filemanager" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
                        </div>
                    </div>
                </div>        
        </div>        
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/admin/filemanager/show.blade.php ENDPATH**/ ?>