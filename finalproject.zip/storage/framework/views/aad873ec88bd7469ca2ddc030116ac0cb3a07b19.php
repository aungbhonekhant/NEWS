<meta charset="UTF-8">
<?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <title> <?php echo e($title->title_name); ?></title>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<link rel="stylesheet" href="<?php echo e(asset('user/bootstrap4/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('user/fontawesome/css/all.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('user/bootstrap4/css/w3.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('user/bootstrap4/css/animate.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('user/imagehover/css/imagehover.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('user/bootstrap4/css/mystyle.css')); ?>">

	<meta property="og:url"           content="<?php echo e(Request::url()); ?>" /><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/user/layout/head.blade.php ENDPATH**/ ?>