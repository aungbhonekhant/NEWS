<?php $__env->startSection('content'); ?>

<div class="container-fluid py-4">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h1 class="font-weight-bold">Latest News</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<h2 class="font-weight-bold">! <?php echo e($posts->count()); ?> Results for <?php echo e($query); ?></h2>
			</div>
		</div>

		
		<div class="row">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="col-12 col-sm-12 col-md-6 col-lg-6 mt-3">
				<div class="shadow">
					<img src="<?php echo e($post->img); ?>" alt="" class="w-100">
					<div class="px-4 pb-4">
						<h3><?php echo e($post->title); ?></h3>
						<p>
							<i class="fas fa-user w3-text-green"></i>
							<span class="w3-text-green ml-2"><?php echo e($post->created_by); ?></span>
							<i class="fas fa-calendar"></i>
							<span><?php echo e($post->created_at->diffForHumans()); ?></span> 
						</p>
						<p>
							<?php echo htmlspecialchars_decode(str_limit($post->content, 150)); ?> 
						</p>
						<a href="<?php echo e(route('home.post', $post->id)); ?>" class="btn px-4 w3-round-xxlarge shadow">Read more</a>
					</div>

				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div><br><br>
		
		

	</div>
</div>		

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-content'); ?>
<script>
		function w3_open() {
		  document.getElementById("mySidebar").style.display = "block";
		  document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
		  document.getElementById("mySidebar").style.display = "none";
		  document.getElementById("myOverlay").style.display = "none";
		}
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finalproject\resources\views/user/search.blade.php ENDPATH**/ ?>